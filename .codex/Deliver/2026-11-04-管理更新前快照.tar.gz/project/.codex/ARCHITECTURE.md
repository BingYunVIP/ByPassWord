# 项目架构摘要

更新时间：2026-11-03（Asia/Singapore）。既有完整设计见 [架构文档](../docs/ARCHITECTURE.md)，现有业务任务见 [任务看板](../docs/TASKS.md)。

- 前端：`frontend/`，Vue 3 + Vite；开发端口 899，`/api` 代理到 `127.0.0.1:8000`（证据：`frontend/package.json`、`frontend/vite.config.js`）。
- 后端：`backend/`，FastAPI + SQLite；通过 `backend/.venv` 运行，开发端口 8000（证据：`backend/pyproject.toml`、`Makefile`）。
- 启动时默认自动迁移数据库，验证必须使用临时库，避免影响现有数据（证据：`backend/app/main.py`、`backend/app/core/config.py`）。
- 本次仅补充根目录开发启动入口，保持既有端口、配置及业务逻辑；详见 [启动修复任务](Task/2026-11-03-dev-all.md)。
